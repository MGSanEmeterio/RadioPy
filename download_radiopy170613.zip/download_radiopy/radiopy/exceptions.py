#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun  1 20:22:03 2017

Title
-----
Module exceptions

Description
-----------
This module contains a variety of classes with the purpose of serving as 
exceptions.See the docstring of each class for the description. 

Metadata
-------- 
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt
"""



class FolderDoesNotExistError(Exception):
    """
    Could be raised at report.Report.createReport().
    
    The folder containing the figures does not exist.
    """
    def __init__(self,value):
        self.value=value
        
    def __str__(self):
        return repr(self.value)
        
        
class EqualIndexesError(Exception):
    """
    Could be raised at observation.Observation.obtainSlope().
    
    The folder containing the figures does not exist.
    """
    def __init__(self,value):
        self.value=value
        
    def __str__(self):
        return repr(self.value)
        
        
        
class BinarySearchNoConvergenceError(Exception):
    """
    Could be raised at AbstractFit or SNFit method binarySearch()
    
    The root binary search algorithm does not converge.
    """
    def __init__(self,value):
        self.value=value
        
    def __str__(self):
        return repr(self.value)
        

class NotImplementedError(Exception):
    """
    Could be raised at method fluxModel in class AbstractModel or at
    method paramSearch in class AbstractFit

    An abstract method was invoked
    
    The abstract method should have been overridden and concrete
    implementation be invoked  
    """        
        
    def __init__(self,value):
        self.value=value
        
    def __str__(self):
        return repr(self.value)
        
