#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 25 13:15:00 2017

Title
-----
Class ResultSequence

Description
-----------
This class contains as attribute a list of objects of the class Result.
Its purpose is to study the whole set of measurements over time, i.e., its time
evolution.

Metadata
-------- 
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt
"""

import radiopy.result as rst

from typing import List
from typing import Tuple

class ResultSequence:
    """
    This class contains as attribute a list of objects of the class
    Result.  Its purpose is to study the whole set of measurements
    over time, i.e. its time evolution.
    """
    
    # -------------------- METHODS --------------------
    
    def __init__(self):
        """
        Constructor method for class ResultSequence.

        It creates empty lists for the results
        """

        # List of class Result instances
        self.resultList = list()

        # List of the ages of each epoch.
        self.tList = list()
        
        # List of the exponents p of each epoch.
        self.pList = list()
        # List of the exponents p of each epoch.
        self.pErrList = list()
        # Average emponent p of all the fitted epochs.
        self.pAvg = float
        # Error of the average p
        self.pAvgErr = float
    
        # List of all the fluxes st (mJy) for each epoch of the sequence.
        self.stList = list()
        # List of the uncertainties of the fluxes st (mJy) for all epochs. 
        self.stErrList = list()
        
        # List of all the frequencies vt (GHz) for each epoch of the sequence.
        self.vtList = list()
        # List of the uncertainties of the frequencies vt (GHz) for all epochs. 
        self.vtErrList = list()
             
        # List of all radious (cm) values for all epochs.
        self.rList = list()
        # List of all uncertainties for the radious (cm) values for each epoch.
        self.rErrList = list()
        # Slope of the radious time evolution model.
        self.rSlope = float
        # Constant of the radious time evolution model.
        self.rConst = float
        
        # List of all magnetic field intensity (G) values for each epoch.
        self.bList = list()
        # List of all uncertainties for the magnetic field intensity
        # (G) values for each epoch.
        self.bErrList = list()
        # Slope of the magnetic field time evolution model.
        self.bSlope = float
        # Constant of the magnetic field time evolution model.
        self.bConst = float
        
        # List of all circumstellar density values for all epochs.
        self.aList = list()
        # List of all uncertainties for the circumstellar density
        # values for each epoch.
        self.aErrList = list()
        # Slope of the circumstellar density time evolution model.
        self.aSlope = float
        # Constant of the circumstellar density time evolution model.
        self.aConst = float
        
    
    def addResult(self, fitResult:rst.Result):
        """
        This method adds an instance of class Result to the list. 

        Parameters
        ----------
        fitResult : Result
            A Result object containing the results for one epoch
            This object will be added to the sequence
        """

        self.resultList.append(fitResult)
        
        
    def setTimeList(self, tList:List[float]):
        """
        This method gives value to the time list, i.e., the age of each epoch.
        
        Parameters
        ----------
        tList : List[float]
            A list containing the t values for each result, i.e,
            the age of each epoch.
        """

        self.tList = tList
        
        
    def setPList(self, pList:List[float]):
        """
        This method gives value to the list of p exponents of each epoch.
        
        Parameters
        ----------
        pList : List[float]
            A list containing the p values for each result, i.e,
            the exponents of the power-law distribution of electrons.
        """

        self.pList = pList
        
        
    def setPErrList(self, pErrList:List[float]):
        """
        This method gives value to the list of errors for the p exponents
        of each epoch.
        
        Parameters
        ----------
        pErrList : List[float]
            A list containing the uncertainties of the p values for each
            result, i.e, the exponents of the power-law distribution of
            electrons.
        """

        self.pErrList = pErrList
      
        
    def setStList(self, stList:List[float]):
        """
        This method gives value to the list of st values of each epoch.
        
        Parameters
        ----------
        stList : List[float]
            A list containing the fluxes st (mJy) for each result.
        """

        self.stList = stList
        
        
    def setStErrList(self, stErrList:List[float]):
        """
        This method gives value to the list of st-error values of each epoch.
        
        Parameters
        ----------
        stErrList : List[float]
            A list containing the uncertainties for fluxes st (mJy) for each
            result.
        """

        self.stErrList = stErrList
        
        
    def setVtList(self, vtList:List[float]):
        """
        This method gives value to the list of vt values of each epoch.
        
        Parameters
        ----------
        vtList : List[float]
            A list containing the vt frequency (GHz) values for each result.
        """
        self.vtList = vtList
        
        
    def setVtErrList(self, vtErrList:List[float]):
        """
        This method gives value to the list of error vt values of each epoch.
        
        Parameters
        ----------
        vtErrList : List[float]
            A list containing the uncertainties of the vt frequency (GHz)
            values for each result.
        """
        self.vtErrList = vtErrList
        
        
    def setREvol(self, rList:List[float], rErrList:List[float], 
                 rSlope:float, rConst:float):
        """
        Gives value to the parameters of the radious time evolution model.
        
        Parameters
        ----------
        rList : List[float]
            A list containing the values for the radious (cm) of all epochs.
        rErrList : List[float]
            A list containing the error for the values of the radious (cm)
            for all epochs.
        rSlope : float
            Slope of the radious time evolution model at logarithmic scale.
        rConst : float
            Constant of the radious time evolution model at logarithmic scale.
        """
        self.rList = rList
        self.rErrList = rErrList
        self.rSlope = rSlope
        self.rConst = rConst
        
    def setBEvol(self, bList:List[float], bErrList:List[float],
                 bSlope:float,bConst:float):
        """
        Gives value to the parameters of the magnetic field time evolution
        model.
        
        Parameters
        ----------
        bList : List[float]
            A list containing the values for the magnetic field (G) of all 
            epochs.
        rErrList : List[float]
            A list containing the error for the values of the magnetic field (G)
            for all epochs.
        bSlope : float
            Slope of the magnetic field time evolution model at logarithmic 
            scale.
        bConst : float
            Constant of the magnetic field time evolution model at logarithmic
            scale.
        """

        self.bList = bList
        self.bErrList = bErrList
        self.bSlope = bSlope
        self.bConst = bConst
    

    def setAEvol(self, aList:List[float], aErrList:List[float],
                 aSlope:float, aConst:float):
        """
        Gives value to the parameters of the circumstellar density time 
        evolution model.
        
        Parameters
        ----------
        aList : List[float]
            A list containing the values for the circumstellar
            density (5e-11 g cm-1) of all epochs.
        rErrList : List[float]
            A list containing the error for the values of the 
            circumstellar density (5e-11 g cm-1) for all epochs.
        aSlope : float
            Slope of the circumstellar density time evolution model at 
            logarithmic scale.
        aConst : float
            Constant of the circumstellar density time evolution model at 
            logarithmic scale.
        """

        self.aList = aList
        self.aErrList = aErrList
        self.aSlope = aSlope
        self.aConst = aConst

        
    def setPAvg(self, pAvg:float, pAvgErr:float):
        """
        This method gives value to the class attributes pAvg and pAvgErr.
        
        Parameters
        ----------
        pAvg : float
            Average exponent p of all the fitted epochs.
        pAvgErr : float
            Error of the average p
        """

        self.pAvg = pAvg
        self.pAvgErr = pAvgErr
        
        
    def getPList(self)->List[float]:
        """
        This method returns the list of p exponents of each epoch.
        
        Returns
        -------
        pList : List[float]
            A list containing the p values for each result, i.e,
            the exponents of the power-law distribution of electrons.
        """

        return self.pList
        
        
    def getPErrList(self)->List[float]:
        """
        This method returns the list of errors for the exponents p
        of each epoch.
        
        Returns
        -------
        pErrList : List[float]
            A list containing the uncertainties of the p values for each
            result, i.e, the exponents of the power-law distribution of
            electrons.
        """

        return self.pErrList        
        
        
    def getPAvg(self)->List[float]:
        """
        This method returns a list containing the values for class
        attributes pAvg and pAvgErr.
        
        Returns
        ----------
        List[float]
            pAvg : float. 
                Average p exponent of all the fitted epochs.
            pAvgErr : float. 
                Error of the average p
        """

        return self.pAvg, self.pAvgErr
        
        
    def getStList(self)->List[float]:
        """
        This method returns the list of st values of each epoch.
        
        Returns
        -------
        stList : List[float]
            A list containing the fluxes st (mJy) for each result.
        """

        return self.stList
        
        
    def getStErrList(self)->List[float]:
        """
        This method returns the list of st-error values of each epoch.
        
        Returns
        -------
        stErrList : List[float]
            A list containing the uncertainties for fluxes st (mJy) for each
            result.
        """

        return self.stErrList
        
        
    def getVtList(self)->List[float]:
        """
        This method returns the list of vt values of each epoch.
        
        Returns
        -------
        vtList : List[float]
            A list containing the vt frequency (GHz) values for each result.
        """

        return self.vtList
        
        
    def getVtErrList(self)->List[float]:
        """
        This method returns the list of error vt values of each epoch.
        
        Returns
        -------
        vtErrList : List[float]
            A list containing the uncertainties of the vt frequency (GHz)
            values for each result.
        """

        return self.vtErrList
        
        
    def getNumResults(self)->int:
        """
        Returns the number of results or epochs.
        
        Returns
        -------
        int
            Number of fitted epochs or results.
        """

        return len(self.resultList)

        
    def getResult(self, index:int)->rst.Result:
        """
        Returns the Result instance from the list corresponding to the
        indicated index.
        
        Parameters
        ----------
        index : int
            Observation's index from the resultList.
        
        Returns
        -------
        Result
            Returns the instance of class Result from the resultList
            corresponding to the given index.
        """

        return self.resultList[index]


    def getTimeList(self)->List[float]:
        """
        This method returns a list containing the age of each epoch.
        
        Returns
        -------
        tList : List[float]
            A list containing the t values for each Result, i.e,
            the age of each epoch.
        """

        return self.tList


    def getREvol(self)->Tuple[List[float],List[float],float,float]:
        """
        Returns the  value of parameters of the radious time evolution model.
        
        Returns
        -------
        rList : List[float]
            A list containing the values for the radious (cm) of all epochs.
        rErrList : List[float]
            A list containing the errors for the radiuos (cm) of all epochs.
        rSlope : float
            Slope of the radious time evolution model.
        rConst : float
            Constant of the radious time evolution model.
        """

        return self.rList, self.rErrList, self.rSlope, self.rConst
        
        
    def getBEvol(self)->Tuple[List[float],List[float],float,float]:
        """
        Returns the value of parameters of the magnetic field time
        evolution model.
        
        Returns
        -------
        bList : List[float]
            A list containing the values for the magnetic field (G) of 
            all epochs.
        bErrList : List[float]
            A list containing the errors for the magnetic field (G) of 
            all epochs.
        bSlope : float
            Slope of the magnetic field time evolution model.
        bConst : float
            Constant of the magnetic field time evolution model.
        """

        return self.bList, self.bErrList, self.bSlope, self.bConst
    
        
    def getAEvol(self)->Tuple[List[float],List[float],float,float]:
        """
        Returns the  value of the parameters of the circumstellar density 
        time evolution model.
        
        Returns
        -------
        aList : List[float]
            A list containing the values for the circumstellar
            density (5e-11 g cm-1) of all epochs.
        aErrList : List[float]
            A list containing the errors for the circumstellar
            density (5e-11 g cm-1) of all epochs.
        aSlope : float
            Slope of the circumstellar density time evolution model.
        aConst : float
            Constant of the circumstellar density time evolution model.
        """

        return self.aList, self.aErrList, self.aSlope, self.aConst
        
