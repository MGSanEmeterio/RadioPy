#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Wed May 24 12:49:26 2017

Title
-----
Class AbstractFit 

Description
-----------
The Class AbstactFit assembles a group of class methods that define
the algorithm for treating radio synchrotron emissions with a
power-law distribution of relativistic electrons, as treated in
Pacholczyk (1970), Chevalier(1998) and Krauss+ (2012). This class
contains methods for the adjustment of data to the theoretical model
described at Class AbstractModel.

Metadata
--------
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""

import numpy as np
import radiopy.result as rst
import radiopy.observation as obs
import radiopy.observation_sequence as obseq
import radiopy.config as config
import radiopy.abstract_model as mod
import radiopy.result_sequence as rstseq
import radiopy.exceptions as excep
import radiopy.fit_parameters as fparams

from typing import Dict

class AbstractFit:
    """
    This class contains functions capable of performing a fitting process
    for measured pairs of flux (mJy) vs frequency (GHz) using the model
    proposed at Krauss+ (2012), implemented in class Model.

    All the methods are class or static methods, i.e., not instance methods

    Before usage the class must be initialized with its init method, which
    requires a concrete model that is a subclass of AbstractModel
    """    
    
    #--------------------- CLASS ATTRIBUTE------------------- 
    # The model used in the fitting algorithm, which describes the theoretical
    # function that obtains the flux given the frequency and some model 
    # parameters.
    # This class attribute is set by the init class method  
    
    model=mod.AbstractModel

    # -------------------- CLASS METHODS --------------------
    @classmethod
    def init(cls,modelToUse):
        """
        Initialize the class with the model that will be used by the methods

        The model should be a subclass of AbstractModel

        Parameters
        ----------
        cls : class
            The current class
        modelToUse: class
            A subclass of AbstractModel
        """

        cls.model=modelToUse


    @classmethod
    def binarySearch(cls, observ:obs.Observation, soughtParam:str, 
                       fitParams:fparams.FitParameters, 
                       **modelParams)->float:
        """
        Binary search algorithm for a fitted value of parameter named 
        soughtParam.
        
        This private classmethod searches for a fitted value of the
        parameter named soughtParam.  The algorithm focuses on finding
        the root of the derivative of chi-square over parameter
        soughtParam. Finding such a root would indicate a value for
        the sought parameter where the weighted quadratic error
        between measuered and theoretical values is minimum.  The
        search is performed using a binary search algorithm.
        
        Parameters
        ----------
        cls : class
            The current class
        observ : Observation
            Instance of class Observation.
        soughtParam : str
            Name of the parameter that will bi fitted
        fitParams : FitParameters
            The parameters that are used by the fitting algorithm
        modelParams : Dict[str,float]
            Dictionary containing the parameters passed to the flux model
            One of these parameters must have the name param
        
        Returns
        -------
        soughtParameterValue : float
            A fitted value of the sougt parameter for which chi-square 
            is minimum.
        """

        # 0)Input data obtained from the observation object
        freq = observ.getFreq()     # In GHz
        flux = observ.getFlux()     # In mJy
        error = observ.getError()   # In mJy
        # 1) We suppose two values of the sought parameter, aiming at obtaining
        #    negative and positive values of the derivative of chi square
        #    and define other parameters 
        p1 = fitParams.preGuess
        p2 = fitParams.postGuess
        
        # Accuracy parameter - minimum value for fitting precision
        fitAccuracy = config.SNConfig.fitAccuracy
        acc = fitAccuracy*fitParams.initialGuess
        #  Step or 'delta' for derivative calculations
        step = 0.1*acc
        # 2) Find appropiate values for initial sought parameters p1 and p2
        #    that satisfy the requirements that p1 leads to a negative value 
        #    of the derivative and p2 to a positive value
        cont = 0
        modelParams[soughtParam]=p1
        while cls.model.chiSqDiff(freq,flux,error,step,soughtParam,
                                  **modelParams)>=0:
            cont = cont+1
            if cont>1000:
                raise excep.BinarySearchNoConvergenceError(
                    'cannot find value to make the derivative '+
                    'of chi square <0')
            p1 = max(p1*fitParams.preFactor,fitParams.min)
            p1 = min(p1,fitParams.max)
            modelParams[soughtParam]=p1
        cont = 0
        modelParams[soughtParam]=p2
        while cls.model.chiSqDiff(freq,flux,error,step,soughtParam,
                                  **modelParams)<=0:
            cont = cont+1
            if cont>1000:
                raise excep.BinarySearchNoConvergenceError(
                    'cannot find value to make the derivative '+
                    'of chi square >0')
            p2 = min(p2*fitParams.postFactor,fitParams.max)
            p2 = max(p2,fitParams.min)
            modelParams[soughtParam]=p2
        # 3) Run binary search algorithm
        while(abs((p1-p2)/p1)>acc):
            halfpoint = (p1+p2)/2
            modelParams[soughtParam]=halfpoint
            HPslope = cls.model.chiSqDiff(freq,flux,error,step,soughtParam,
                                          **modelParams)
            if HPslope>0:
                p2 = halfpoint
            else:
                p1 = halfpoint
    
        soughtValue = halfpoint
        
        return soughtValue
        
        
    @classmethod
    def paramSearch(cls, observ:obs.Observation)-> Dict[str,float]:
        """
        Fit parameters in an iterative search.
        
        This method finds the best theoretical parameters a the Krauss+ model
        adjustment to a set of measured data and returns a list of parameters.
        
        Parameters
        ----------
        cls: class
            The current class
        observ : Observation
            An instance of the class Observation.
            
        Returns
        -------
        Dict[str,float]
            This dictionary contains the following pairs of keyword-value:
                'p',float
                    Exponent of the power-law distribution of electrons.
                'st',float
                    S_tau ; flux (mJy) at the frequency which the optical 
                    thickness 'tau' is 1.
                'vt',float
                    nu_tau ; frequency (GHz) at which the optical thickness 
                    tau is 1.
                'rChiSq',float
                    Reduced chi-square function per degree of freedom.
                'quadErr',float
                    Summation of quadratic errors between measured and
                    theoretical points.
                'stdErrReg',float
                    Standard error of the regression.
        """

        raise excep.NotImplementedError(
            'Abstract method __paramSearch should be overridden in a subclass')
        
        
    @classmethod
    def fitEpoch(cls, observ:obs.Observation)->rst.Result:
        """
        Finds a theoretical curve that fits the measured data.
        
        This method uses binary search algoritm to find the roots of the
        derivative of logarithmic chi-square function over differente fit
        parameters, i.e. st,vt and p. It makes an instance of class Result
        with the best fitted values for those parameters.
        
        Parameters
        ----------
        cls: class
            The current class
        observ : Observation
            An instance of the class Observation.
            
        Returns
        -------
        fitResult : Result
            An instance of the class Result containing the best values
            for the fitted model parameters.
        """
        error = observ.getError()
        if config.SNConfig.enableErrCorr:
            param = cls.paramSearch(observ)
            
            corrFactor = np.sqrt(param['rChiSq'])
            corrError = corrFactor*error
            observ.setError(corrError)
        else:
            corrFactor = 1
        fitParams = cls.paramSearch(observ)
        fitResult = rst.Result()
        fitResult.setFitting(fitParams['p'],fitParams['st'],fitParams['vt'])
        relativeErr = fitParams['stdErrReg']/fitParams['st']*100
        fitResult.setFittingErr(fitParams['p']*relativeErr/100,
            fitParams['stdErrReg'],fitParams['vt']*relativeErr/100)
        fitResult.setFittingGoodness(fitParams['rChiSq'],
            fitParams['quadErr'],fitParams['stdErrReg'],corrFactor)               
        fitResult.setTime(observ.getTime())
        
        return fitResult
        
        
    @classmethod
    def calculatePhysParams(cls, fitResult:rst.Result)->rst.Result:
        """
        Calculates physical parameters from a fitting.
        
        This method calculates the value of three physical magnitudes
        inferred by the theoretical curve defined by the fitting parameters.
        
        Parameters
        ----------
        cls: class
            The current class
        fitResult : Result
            An instance of the class Result containing the best values
            for fitting parameters.
            
        Returns
        -------
        fitResult : Result
            The same instance of class Result now containing both the
            best values for fitting parameters and the inferred values
            for physical magnitudes.        
        """

        fitParams = fitResult.getFitting()
        fitGoodness = fitResult.getFittingGoodness()
        stdErrorReg = fitGoodness['stdErrorReg']
        t = fitResult.getTime()
        # We handle a radio window between 1GHz and 100GHz
        # This radio window is divided into 200 frequencies using 
        # a logarithmic scale
        freqExpandedLog = np.linspace(np.log(1),np.log(100),1000)
        freqExpanded = np.e**freqExpandedLog
        sFlux = cls.model.fluxModelArray(freqExpanded,p=fitParams['p'],
                                st=fitParams['st'],vt=fitParams['vt'])
        sm = max(sFlux)
        vm=0
        for j in range(0,len(sFlux)):
            if sFlux[j] == max(sFlux):
                vm = freqExpanded[j]
        fitResult.setTheoreticalCurve(freqExpanded,sFlux)
        fitResult.setMax(sm,vm)
        fitResult.setMaxErr(stdErrorReg,vm*stdErrorReg/sm)
        calcR = cls.model.SNr(sm,vm,stdErrorReg)
        calcB = cls.model.SNb(sm,vm,stdErrorReg)
        calcA = cls.model.SNa(sm,vm,stdErrorReg,t)
        fitResult.setPhysParams(calcR[0],calcB[0],calcA[0])
        fitResult.setPhysParamsErr(calcR[1],calcB[1],calcA[1])
        
        return fitResult
    
    @classmethod    
    def sequenceFitting(
            cls, observSeq:obseq.ObservationSequence)->rstseq.ResultSequence:
        """
        This methdod invokes methods from this class to calculate
        a sequence of Results from a sequence of Observations.
        
        Parameters
        ----------
        cls: class
            The current class
        observSeq : ObservationSequence
            An instance of class ObservationSequence containing a list
            of instances of class Observation.
            
        Returns
        -------
        resultSeq : ResultSequence
            A sequence of instances of class Result calculated from the
            ObservationSequence.
        """
        num = observSeq.getNumObservations()
        resultSeq = rstseq.ResultSequence()
        for i in range(0,num):
            print('Fitting Epoch number: ',i+1,' of ',num,' ...')
            observ = observSeq.getObservation(i)
            fitResult = rst.Result()
            fitResult = cls.fitEpoch(observ)
            fitResult = cls.calculatePhysParams(fitResult)
            resultSeq.addResult(fitResult)
            
        return resultSeq
