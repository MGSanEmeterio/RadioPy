#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Wed May 31 00:10:22 2017

Title
-----
Class GlobalData

Description
-----------
This class contains attributes capable of recording data in form of
several strings and floats regarding metadata of the observations.
Those data are usually extracted from a .csv file and stored
here. They include the authors of the experiment, the measuring
equipment, dates, distances and alike.

Metadata
-------- 
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""

class GlobalData:
    """
    This class records as class attributes some data in form of
    several strings and floats regarding metadata of the observations.
    Those data are usually extracted from the header of a .csv file
    and stored here. They include the authors of the experiment, the
    measuring equipment, dates, distances and alike.
    
    Attributes
    ----------
    title : str
        A string containing the title of the experiment.
    authors : str
        A string containing the authors of the research.
    organization : str
        A string containing the name of the research organization.
    eventName : str
        A string containing the name of the observed event.
    eventStartDate : str
        A string containing the date when the observed event
        was first noticed. Format YEAR/MONTH/DAY is expected.
    eventDistance : float
        Observer-event distance (Mpc).
    eventDistanceErr : float
        Error of the observer-event distance (Mpc).
    measuringEquipment : str
            A string containing the name of the masuring equipment.
    """

    title = str
    authors = str
    organization = str
    eventName = str
    eventStartDate = str
    eventDistance = float
    eventDistanceErr = float
    measuringEquipment = str
