#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 24 12:49:26 2017

Title
-----
Class SNFit(AbstractFit)

Description
-----------
The Class SNFit assembles a group of class methods that define the algorithm
for treating radio synchrotron emissions with a power-law distribution of
relativistic electrons, as treated in Pacholczyk (1970), Chevalier(1998)
and Krauss+ (2012). This class contains methods for the adjustment of data to
the theoretical model described at Class KraussModel.

Metadata
--------
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""
import numpy as np
import radiopy.result as rst
import radiopy.observation as obs
import radiopy.config as config
import radiopy.krauss_model as mod
import radiopy.result_sequence as rstseq
import radiopy.exceptions as excep
import radiopy.abstract_model as absmod
import radiopy.abstract_fit as absfit
import radiopy.fit_parameters as fparams

from typing import Dict

class SNFit(absfit.AbstractFit):
    """
    This class contains functions capable of performing a fitting process
    for measured pairs of flux (mJy) vs frequency (GHz) data using the model
    proposed at Krauss+ (2012) implemented in class Model.
    """    
    
    # -------------------- METHODS --------------------

    @classmethod
    def paramSearch(cls, observ:obs.Observation)-> Dict[str,float]:
        """
        Fit parameters in an iterative search.  Overrides the method
        defined in AbstractFit
        
        This method finds the best theoretical parameters a the Krauss+ model
        adjustment to a set of measured data and returns a list of parameters.
        
        Parameters
        ----------
        cls: class
            The current class
        observ : Observation
            An instance of the class Observation.
            
        Returns
        -------
        Dict(str,float)
            This dictionary contains the following pairs of keyword-value:
                'p',float
                    Exponent of the power-law distribution of electrons.
                'st',float
                    S_tau ; flux (mJy) at the frequency which the optical 
                    thickness 'tau' is 1.
                'vt',float
                    nu_tau ; frequency (GHz) at which the optical thickness 
                    tau is 1.
                'rChiSq',float
                    Reduced chi-square function per degree of freedom.
                'quadErr',float
                    Summation of quadratic errors between measured and
                    theoretical points.
                'stdErrReg',float
                    Standard error of the regression.
        """

        freq = observ.getFreq()     # In GHz
        flux = observ.getFlux()     # In mJy
        error = observ.getError()   # In mJy
        # prepare fit parameters for st, vt, p
        stGuess=max(flux)
        stFitParams=fparams.FitParameters(initialGuess=stGuess,
            preGuess=stGuess*0.67, postGuess=3*stGuess, preFactor=0.5, 
            postFactor=2.0)
        vtGuess=freq[observ.findMaxFluxIndex()]
        vtFitParams=fparams.FitParameters(initialGuess=vtGuess,
            preGuess=vtGuess*0.67, postGuess=1.5*vtGuess, preFactor=0.9, 
            postFactor=1.1)
        inip = observ.obtainSlope(observ.findMaxFluxIndex()+2,len(freq)-2)[1]
        pFitParams=fparams.FitParameters(initialGuess=inip,
            preGuess=inip*0.67, postGuess=1.5*inip, preFactor=0.9, 
            postFactor=1.1, min=1.01)

        if config.SNConfig.enableFixedP:
            vt = freq[observ.findMaxFluxIndex()]
            p = config.SNConfig.fixedP
            cont = 0
            nextChiSq = 0.0001
            ratio = 1
            while(ratio>0.0001 and cont<=100):
                chiSq = nextChiSq
                st = cls.binarySearch(observ, 'st', stFitParams, p=p, 
                                        st=stGuess, vt=vt)        
                vt = cls.binarySearch(observ, 'vt', vtFitParams, p=p, 
                                        st=st, vt=vtGuess)
                nextChiSq = cls.model.chiSqSum(freq, flux, error, p=p, 
                                               st=st, vt=vt)
                ratio = abs(nextChiSq-chiSq)*100/nextChiSq
                cont = cont + 1
        else:
            vt = freq[observ.findMaxFluxIndex()]
            slope = observ.obtainSlope(observ.findMaxFluxIndex()+2,len(freq)-2)
            p = slope[1]
            cont = 0
            nextChiSq = 0.0001
            ratio = 1
            while(ratio>0.0001 and cont<=100):
                chiSq = nextChiSq
                st =  cls.binarySearch(observ, 'st', stFitParams, p=p, 
                                        st=stGuess, vt=vt)        
                vt = cls.binarySearch(observ, 'vt', vtFitParams, p=p, 
                                        st=st, vt=vtGuess)
                p = cls.binarySearch(observ, 'p', pFitParams, p=p, 
                                        st=st, vt=vt)
                nextChiSq = cls.model.chiSqSum(freq,flux,error,p=p,st=st,vt=vt)
                ratio = abs(nextChiSq-chiSq)*100/nextChiSq
                cont = cont + 1
        # Reduced chi-square function per degree of freedom
        rChiSq = cls.model.rChiSqSum(
            freq,flux,error,p=p,st=st,vt=vt)/(len(flux)-3)
        quadErr = cls.model.quadErrSum(freq,flux,p=p,st=st,vt=vt)
        stdErrReg = np.sqrt(quadErr/len(flux))
        
        return dict(p=p, st=st, vt=vt, rChiSq=rChiSq, quadErr=quadErr,
                    stdErrReg=stdErrReg)
