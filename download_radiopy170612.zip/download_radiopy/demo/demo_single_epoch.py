#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Mon May 29 19:43:38 2017

Title
-----
Test Epoch

Description
-----------

Welcome to RadioPy! This is an example of an application for the
package 'radiopy'.  Second of a series of three tutorials, this one
explores the case of reading frequency (GHz) and flux (mJy) arrays of
a single epoch or observation from a .csv file (following the format
described at radiopy/docs/radiopy_csv_format_guide).

The goal is to perform a complete fitting to the data using the
synchrotron self-absorption (SSA) model. This example shows the case
of a single epoch. Nevertheless, expanding it into a series or
sequence of epochs is easy using the class ObservationSequence (see
Documentation of the package).

Metadata
--------
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""
# First the imports
import radiopy as rpy

# This package was created following the Object Oriented Programming
# (OOP) architechture. Thus the input data must be recorded in an
# instance of class Observation.

#initialize the fitting class to use the desired model
rpy.SNFit.init(rpy.KraussModel)

# Create an instance of Class Observation. That object will record the data.
observ = rpy.Observation()

# In order to record the data, the class Observation has the method named 
# 'readEpochCSV'. Its purpose is to read the data from a CSV file and record
# it inside the istance's object attributes.
observ.readEpochCSV('data_krauss_2012_single_epoch.csv')

# Now that the Observation instance has recorded the data, we proceed
# with the fitting. It is done in two steps. The first one is to
# perform a fitting on the measured data. The second step is to use
# the fitted parameters to infer information about the physical
# parameters.

# The fitting is using the method 'fitEpoch' of class SNFit. This
# method receives an observation as parameter and returns an instance
# of class Result. This instance will store the fitted values but it
# will not yet contain the physical information.
fitResult = rpy.SNFit.fitEpoch(observ)

# The next step is to infer some physical information from that
# Result. To do it, the class SNFit has the method
# "calculatePhysParams". That method receives a result and returns the
# same object with the physical information filled in.
fitResult = rpy.SNFit.calculatePhysParams(fitResult)

# Now calculations are complete and we have an object Observation that contains
# all measurements and an object Result containing all theoretical values, the 
# fitted parameters and the values of the three physical magnitudes that this model
# is capable of inferring. All is left is to display those results, 
# graphically or written.

# This method of class SNGraph plots in the iPython console the treated epoch.
rpy.SNGraph.plotEpoch(observ,fitResult)

# The method 'infoEpoch' of class Report displays the Result's info on
# the screen.
rpy.Report.infoEpoch(fitResult)
