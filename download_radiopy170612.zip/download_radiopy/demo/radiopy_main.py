#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Thu Jun  1 04:10:17 2017

Title
-----
Main

Description
-----------
Welcome to RadioPy! This .py main program is a tool for using package
radiopy in an easy, direct and fast way. This app reads data from a
.csv file (following the format described at
radiopy/docs/radiopy_csv_format_guide.txt) and makes an HTML and a PDF
report containing all data and results concerning the SSA model
fitting for the provided data.

The reports will be stored at directory 'reports', whose path is
defined at class SNConfig with the variable
'reportPath'. Additionally, the figures present on such report will be
also stored at directory 'figures'. Once again that directory is
defined as a path at class SNConfig (figurePath).

Metadata
--------
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""

import radiopy as rpy

# In the method 'readCSV', introduce the name of the .csv file that
# the program must read, following the format described at the
# instructions. The program will do the rest.

# Initialize the fitting class to use the desired model
rpy.SNFit.init(rpy.KraussModel)

# New instance of class ObservationSequence
observSeq = rpy.ObservationSequence()
# Read and record the data from the csv file
filename='data_krauss_2012.csv'
print ('reading CSV file: ',filename)
observSeq.readCSV(filename)

# From the observations, calculate a sequence of Results.
resultSeq = rpy.SNFit.sequenceFitting(observSeq)

# Save the figures for the fittings at folder 'figures'.
print('Saving graphs in demo/'+rpy.SNConfig.figurePath)
rpy.SNGraph.saveSequence(observSeq,resultSeq)

# Calculations of the temporal evolution of the parameters of the 
# ResultSequence.
resultSeq = rpy.TimeEvol.timeEvol(resultSeq)
# Now save the figures resulting from such calculations.
rpy.SNGraph.saveTimeEvol(resultSeq)

# Create an html report in folder 'reports' using svg figures.
print('Creating html and pdf reports in demo/'+rpy.SNConfig.reportPath)
rpy.Report.createHTMLReport(resultSeq,'krauss_report','svg')

# Create a pdf report in folder 'reports'.
rpy.Report.createPDFReport(resultSeq,'krauss_report')

print('End job')
