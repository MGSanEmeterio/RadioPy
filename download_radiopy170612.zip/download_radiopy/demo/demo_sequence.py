#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Sat May 27 14:17:33 2017

Title
-----
Test

Description 
----------- 

Welcome to RadioPy! This is an example of application for the package
'radiopy'.  First of a series of three tutorials, this one explores
the case of reading frequency (GHz) and flux (mJy) arrays of a
sequence of epochs or observations from a .csv file (following the
format described at radiopy/docs/radiopy_csv_format_guide).

The goal is to perform a complete fitting to the data using the
synchrotron self-absorption (SSA) model. Then, for the sequence of
data it is possible to compare the temporal evolution of the physical
parameters, such as the expansion of the supernova radious 'R'.

Metadata
--------
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""
# First the imports
import radiopy as rpy

# This package was created following the Object Oriented Programming
# (OOP) architechture. Thus the input data must be recorded as an
# instance of class ObservationSequence.

#initialize the fitting class to use the desired model
rpy.SNFit.init(rpy.KraussModel)

# Create an instance of Class ObservationSequence. That object will record
# the data of all the measured epochs within a series of Observation instances.
observSeq = rpy.ObservationSequence()

# In order to record the data, the class ObservationSequence has the method
# named 'readCSV' whos purpose is to read the data from a CSV file and record
# it inside the istance's attributes (a list of Observations).
observSeq.readCSV('data_krauss_2012.csv')

# Now that the ObservationSequence instance has recorded the data, we
# proceed with the fitting. It is done in two steps. The first one is
# to perform a fitting on the measured data. The second step is to use
# the fitting parameters to infer information about the physical
# parameters.

# The class SNFit has an special method 'sequenceFitting' that
# performs the complete fitting for all Observations in the
# ObservationSequence in a single step, returning an istance of class
# ResultSequence, i.e., a list of instances of class Result. Thus the
# Results of the ResultSequence will contain the results for each
# epoch.
resultSeq = rpy.SNFit.sequenceFitting(observSeq)

# Now the first calculations are complete and we have an object
# ObservationSequence that contains all measurements for all epochs
# and an object ResultSequence containing all theoretical values,
# fitted parameters and the values of the three physical magnitudes
# for each epoch. The next step is displaying those results
# graphically or written.

# This method of class SNGraph plots in the iPython console all
# results for all epochs, along with some variable values.
rpy.SNGraph.plotSequence(observSeq,resultSeq)

# The study of a sequence allows us to examine the time evolution of
# the fitted parameters. From the scientific point of view this is one
# of the most interesting features of the whole experiment. The class
# TimeEvol posseses a method capable of studying the big picture and
# extracting some results. This method is called 'timeEvol' and
# updates the attributes of a ResultSequence instance by adding the
# physical information.
resultSeq = rpy.TimeEvol.timeEvol(resultSeq)

# The SNGraph's method 'plotTimeEvol' displays on the screen the
# evolution of physical magnitudes R, B and A with some basic
# information about the temporal behaviour.
rpy.SNGraph.plotTimeEvol(resultSeq)
