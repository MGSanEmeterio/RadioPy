radiopy.result module
=====================

.. automodule:: radiopy.result
    :members:
    :undoc-members:
    :show-inheritance:
