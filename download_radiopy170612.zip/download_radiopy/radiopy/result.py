#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 24 16:30:12 2017

Title
-----
Class Result

Description
-----------
The Class Result records processed data of frequency and flux for a single
epoch or day measurement. Its methods can record fitting and physical
parameters in its attributes.

Metadata
-------- 
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""

import numpy as np

from typing import Dict

class Result:
    """
    The Class Result records processed data of frequency and flux for a single
    epoch or day measurement. Its methods can record fitting and physical
    parameters in its attributes.
    """
    
    def _init_(self):
        """
        Constructor method for class Result
        """
        # Age in days
        self.t = float
        
        # p ; exponent of the power-law distribution of electrons
        self.p = float
        # p uncertainty
        self.pErr = float
        
        # S_tau ; flux (mJy) at the frequency which the optical
        # thickness 'tau' is 1.
        self.st = float
        # st uncertainty (mJy)
        self.stErr = float
        
        # nu_tau ; frequency (GHz) at which the optical thickness tau is 1.
        self.vt = float
        # vt uncertainty (GHz)
        self.vtErr = float
        
        # Reduced chi-square per degree of freedom for an epoch
        self.rChiSq = float
        
        # Quadratic error for an epoch
        self.quadError = float
        
        # Standard error of the regression. Absolute error for
        # theoretical flux (mJy)
        self.stdErrorReg = float
        
        # Flux's error bars correction factor.
        self.errorCorrFactor = float
        
        # Theoretical set of frequencies (GHz)
        self.freqExpanded = list()
        # Theoretical flux values calculated with fit parameters.
        self.sFlux = list()
        
        # Maximum flux for the theoretical curve (mJy)
        self.sm = float
        # Maximum flux uncertainty (mJy)
        self.smErr = float
        
        # Frequency for the theoretical maximum flux (GHz)
        self.vm = float
        # Uncertainty for frequency at the theoretical maximum flux (GHz)
        self.vmErr = float
        
        
        # Shockwave radious of the SN (cm)
        self.r = float
        # Radious error (cm)
        self.rErr = float
        
        # Intensity of the magnetic field (G)
        self.b = float
        # Magnetic field error
        self.bErr = float
        
        # Circumstellar density parametrized as A / (5e-11 g cm-1)
        self.a = float
        # Uncertainty of the parametrized circumstellar density (5e-11 g cm-1)
        self.aErr = float
    
    # -------------------- METHODS --------------------
    
    def setTime(self, t:float):
        """
        This method gives value to attribute time "t" (days)
        
        Parameters
        ----------
        t : float
            Lifetime of the SuperNova in days.
        """

        self.t = t

        
    def setFitting(self, p:float, st:float, vt:float):
        """
        This method gives value to fit parameters p, st (mJy) and vt (GHz).
        
        Parameters
        ----------
        p : float
            Exponent of the power-law distribution of electrons.
        st : float
            S_tau ; flux (mJy) at the frequency which the optical 
            thickness 'tau' is 1.
        vt : float
            nu_tau ; frequency (GHz) at which the optical thickness tau is 1.
        """

        self.p = p
        self.st = st
        self.vt = vt
    

    def setFittingErr(self, pErr:float, stErr:float, vtErr:float):
        """
        This method gives value to the uncertainties of the
        fit parameters p, st (mJy) and vt (GHz).
        
        Parameters
        ----------
        pErr : float
            Error for p, exponent of the power-law distribution of electrons.
        stErr : float
            Error for S_tau ; flux (mJy) at the frequency which the 
            optical thickness 'tau' is 1.
        vtErr : float
            Error for nu_tau ; frequency (GHz) at which the optical 
            thickness tau is 1.
        """

        self.pErr = pErr
        self.stErr = stErr
        self.vtErr = vtErr
        
        
    def setFittingGoodness(self, rChiSq:float, quadError:float, 
                           stdErrorReg:float, errorCorrFactor:float):
        """This method gives value to the parameters that indicate the
        goodness of the fit and its associated parameters, such as the
        chi-square function, the quadratic error, standard error of
        the regression or the error bar correction factor.
        
        Parameters
        ----------
        rChiSq : float
            Reduced chi-square function per degree of freedom.
        quadError : float
            Quadratic error for measured vs theoretical fluxes.
        stdErrorReg : float
            Standard error of the regression. Absolute error
            for theoretical flux (mJy).
        errorCorrFactor : float
            Error bar correction factor for reduced chi-square per
            degree of freedom to be close to 1. Sometimes measurement
            equipment does not act correctly as stated at Krauss+
            (2012).
        """

        self.rChiSq = rChiSq
        self.quadError = quadError
        self.stdErrorReg = stdErrorReg
        self.errorCorrFactor = errorCorrFactor
                
        
    def setTheoreticalCurve(self, freqExpanded:np.ndarray, sFlux:np.ndarray):
        """
        Records a theoretical flux vs freq curve calculated with the fit 
        parameters.
        
        Parameters
        ----------
        freqExpanded : array[float]
            A more complete set of frequency data (from 1 GHz to 100GHz)
        sFlux : array[float]
            Set of theoretical flux values (mJy) for the frequencies of the
            freqExpanded array, calculated with the fit parameters.        
        """

        self.freqExpanded = freqExpanded
        self.sFlux = sFlux

    
    def setMax(self, sm:float, vm:float):
        """
        This method gives value to fit results sm and vm.
        
        Parameters
        ----------
        sm : float
            Maximum theoretical flux (mJy).
        vm : float
            Frequency (GHz) at which the theoretical spectra attains 
            its maximum.
        """

        self.sm = sm
        self.vm = vm
        
        
    def setMaxErr(self, smErr:float, vmErr:float):
        """
        This method gives value to the uncertainties for the fit
        results sm and vm.
        
        Parameters
        ----------
        smErr : float
            Error for the maximum theoretical flux (mJy).
        vmErr : float
            Error for the frequency (GHz) at which the 
            theoretical spectra attains its maximum.
        """
        self.smErr = smErr
        self.vmErr = vmErr
        

    def setPhysParams(self, r:float, b:float, a:float):
        """
        This method gives value to the physical magnitudes
        that the model is capable to infer; r (cm), b (G) and a (5e-11 g cm-1).
        
        Parameters
        ----------
        r : float
           Shockwave radious (cm).
        b : float
            Intensity of the magnetic field (G).
        vt : float
            Circumstellar density parametrized as a / (5e-11 g cm-1).
        """
        
        self.r = r
        self.b = b
        self.a = a
        
        
    def setPhysParamsErr(self, rErr:float, bErr:float, aErr:float):
        """
        This method gives value to the errors of the physical magnitudes
        inferred by the fitting; r (cm), b (G) and a (5e-11 g cm-1).
        
        Parameters
        ----------
        rErr : float
            Error of the shockwave radious (cm).
        bErr : float
            Error of the intensity of the magnetic field (G).
        aErr : float
            Error of the parametrized circumstellar density (5e-11 g cm-1).
        """

        self.rErr = rErr
        self.bErr = bErr
        self.aErr = aErr
        

    def getTime(self)->float:
        """
        Returns the SN lifetime at the moment of the observation (in days).
        
        Returns
        -------
        float
            Age of the SN in days.
        """

        return self.t

        
    def getFitting(self)->Dict[str,float]:
        """
        Returns a dictionary containing three parameters of the fitting.
        
        Returns
        -------
        Dict[str,float]
            This dictionary contains the following keyword-value pairs:
                'p',float
                    Exponent of the power-law distribution of electrons.
                'st',float
                    S_tau ; flux (mJy) at the frequency which the optical 
                    thickness 'tau' is 1.
                'vt',float
                    nu_tau ; frequency (GHz) at which the optical thickness 
                    tau is 1.
        """

        return dict(p=self.p,st=self.st, vt=self.vt)
        

    def getFittingErr(self)->Dict[str,float]:
        """
        Returns a dictionary containing errors for the three parameters of
        the fitting.
        
        Returns
        -------
        Dict[str,float]
            This dictionary contains the following keyword-value pairs:
                'pErr',float
                    Error for p, exponent of the power-law distribution 
                    of electrons.
                'stErr',float
                    Error for S_tau ; flux (mJy) at the frequency which the 
                    optical thickness 'tau' is 1.
                'vtErr',float
                    Error for nu_tau ; frequency (GHz) at which the optical 
                    thickness tau is 1.
        """

        return dict(pErr=self.pErr,stErr=self.stErr,vtErr=self.vtErr)
        

    def getFittingGoodness(self)->Dict[str,float]:
        """
        This method returns a dictionary containing the value of the parameters 
        that indicates the goodness of the fit and its associated variables,
        such as the reduced chi-square function per degree of freedom,
        the quadratic error, standard error of the regression or the error bar.
        correction factor.
        
        Returns
        -------
        Dict[str,float]
            This dictionary contains the following keyword-value pairs:
                'rChiSq',float
                    Reduced chi-square function per degree of freedom.
                'quadError',float
                    Quadratic error for measured vs theoretical fluxes.
                'stdErrorReg',float
                    Standard error of the regression (%). Gives relative 
                    uncertainty for the fit parameters.
                'errorCorrFactor',float
                    Error bar correction factor for reduced chi-square
                    per degree of freedom to be 1. Sometimes
                    measurement equipment does not act correctly as
                    stated at Krauss+ (2012).
        """

        return dict(rChiSq=self.rChiSq, quadError=self.quadError, 
                stdErrorReg=self.stdErrorReg, 
                errorCorrFactor=self.errorCorrFactor)
        
        
    def getTheoreticalCurve(self)->Dict[str,float]:
        """
        Returns a dictionary of arrays containing theoretical flux vs freq
        curve calculated with the fit parameters.
        
        Returns
        -------
        Dict[str,float]:
            This dictionary contains the following pairs:
                'freqExpanded',array[float]
                    A more complete set of frequency data (from 1 GHz to 100GHz)
                'sFlux',array[float]
                    Set of theoretical flux values for the frequencies of the
                    freqExpanded array, calculated with the fit parameters.

        """
        return dict(freqExpanded=self.freqExpanded, sFlux=self.sFlux)       


    def getMax(self)->Dict[str,float]:
        """
        This method returns a dictionary with the fit results values sm
        and vm.
        
        Returns
        -------
        Dict[str,float]: 
            This dictionary contains the following pairs:
                'sm',float
                    Maximum theoretical flux (mJy).
                'vm',float
                    Frequency (GHz) at which the theoretical spectra attains 
                    its maximum.
        """

        return dict(sm=self.sm, vm=self.vm)

        
    def getMaxErr(self)->Dict[str,float]:
        """
        This method returns a dictionary with the values of the uncertainties
        for the fit results sm and vm.
        
        Returns
        -------
        Dict[str,float]: 
            This dictionary contains the following pairs:
                'smErr',float
                    Error for the maximum theoretical flux (mJy).
                'vmErr',float
                    Error for the frequency (GHz) at which the 
                    theoretical spectra attains its maximum.
        """

        return dict(smErr=self.smErr, vmErr=self.vmErr)
        
        
    def getPhysParams(self)->Dict[str,float]:
        """
        This method returns a dictionary with values of the physical magnitudes
        that the model is capable to infer r (cm), b (G) and a (5e-11 g cm-1).
        
        Returns
        -------
        Dict[str,float]: 
            This dictionary contains the following pairs of keyword-value:
                'r',float
                   Shockwave radious (cm).
                'b',float
                    Intensity of the magnetic field (G).
                'a',float
                    Circumstellar density parametrized as a / (5e-11 g cm-1).

        """

        return dict(r=self.r, b=self.b, a=self.a)
        

    def getPhysParamsErr(self)->Dict[str,float]:
        """
        This method returns a dictionary with values of the errors of the
        physical magnitudes inferred by the fitting: r (cm), b (G) and
        a (5e-11 g cm-1).
        
        Returns
        -------
        Dict[str,float]:
            This dictionary contains the following pairs of keyword-value:
                'rErr',float:
                    Error of the shockwave radious (cm).
                'bErr',float:
                    Error of the intensity of the magnetic field (G).
                'aErr',float:
                    Error of the parametrized circumstellar density 
                    (5e-11 g cm-1).
        """

        return dict(rErr=self.rErr, bErr=self.bErr, aErr=self.aErr)

