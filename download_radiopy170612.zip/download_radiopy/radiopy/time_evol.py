#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Thu May 25 18:51:11 2017

Title
-----
Class TimeEvol

Description
-----------
This class has methods capable of calculating the time evolution of
several physical magnitudes.

The time evolution is calculated for the shockwave radious of the SN,
R, the intensity of the magnetic field, B, and the circumstellar
density, A

Metadata
-------- 
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""
import radiopy.krauss_model as mod
import result_sequence as rstseq
import numpy as np
import lmfit



class TimeEvol:
    """
    This class has methods capable of calculating the time evolution
    of several magnitudes.

    The time evolution is calculated for the shockwave radious of the
    SN, R, the intensity of the magnetic field, B, and the
    circumstellar density, A
    """        

    @staticmethod
    def timeEvol(fitResultSeq:rstseq.ResultSequence):
        """
        Straight-line fitting for the evolution of ResultSequence parameters
        'R', 'B' and 'A' over age 't'.
        
        Parameters
        ----------
        fittSeq : ResultSequence
            An instance of class ResultSequence.
            
        Returns
        -------
        fittSeq : ResultSequence
            The same ResultSequence with additional parameters filled in: 
            timeList, rEvol,bEvol,aEvol.
        """

        tList = list()
        
        pList = list()
        pErrList = list()
        
        stList = list()
        stErrList = list()
        
        vtList = list()
        vtErrList = list()
        
        rList = list()
        rErrList = list()
        
        bList = list()
        bErrList = list()
        
        aList = list()
        aErrList = list()
        
        num = fitResultSeq.getNumResults()
        for i in range(0,num):
            fitResult = fitResultSeq.getResult(i)
            tList.append(fitResult.getTime())
            fittingParams = fitResult.getFitting()
            pList.append(fittingParams['p'])
            stList.append(fittingParams['st'])
            vtList.append(fittingParams['vt'])
            fittingErrors = fitResult.getFittingErr()
            pErrList.append(fittingErrors['pErr'])
            stErrList.append(fittingErrors['stErr'])
            vtErrList.append(fittingErrors['vtErr'])
            physParams = fitResult.getPhysParams()
            rList.append(physParams['r'])
            bList.append(physParams['b'])
            aList.append(physParams['a'])
            physErr = fitResult.getPhysParamsErr()
            rErrList.append(physErr['rErr'])
            bErrList.append(physErr['bErr'])
            aErrList.append(physErr['aErr'])
        # Calculating pAgv
        pAvg = 0
        for j in range(0,len(pList)):
            pAvg = pAvg + pList[j]
        pAvg = pAvg/len(pList)
        # Calculating pAvgErr
        pAvgErr = 0
        for k in range(0,len(pList)):
            pAvgErr = pAvgErr + (pList[k]-pAvg)**2
        pAvgErr = np.sqrt(pAvgErr/len(pList))
        
        
        # Straight-line FITTING - must be done at logarithmic scale
        # Model
        tList1 = np.log(tList)
        rList1 = np.log(rList)
        rErrList1 = np.log(rErrList)
        
        bList1 = np.log(bList)
        bErrList1 = np.log(bErrList)
        
        aList1 = np.log(aList)
        aErrList1 = np.log(aErrList)
        
        
        model = lmfit.Model(mod.KraussModel.modelStraightLine)
        model.set_param_hint('m',value=1)
        model.set_param_hint('b',value=1)
        # Fitting
        fitR = model.fit(rList1, x=tList1,weights=rErrList1)
        fitB = model.fit(bList1, x=tList1,weights=bErrList1)
        fitA = model.fit(aList1, x=tList1,weights=aErrList1)
        # Results
        rValues = fitR.best_values
        rSlope = rValues['m']
        rConst1 = rValues['b']
        rConst = np.e**(rConst1)
        
        bValues = fitB.best_values
        bSlope = bValues['m']
        bConst1 = bValues['b']
        bConst = np.e**(bConst1)
        
        aValues = fitA.best_values
        aSlope = aValues['m']
        aConst1 = aValues['b']
        aConst = np.e**(aConst1)
        
        # Record the results
        fitResultSeq.setTimeList(tList)
        fitResultSeq.setPList(pList)
        fitResultSeq.setPErrList(pErrList)
        fitResultSeq.setStList(stList)
        fitResultSeq.setStErrList(stErrList)
        fitResultSeq.setVtList(vtList)
        fitResultSeq.setVtErrList(vtErrList)
        fitResultSeq.setPAvg(pAvg,pAvgErr)
        fitResultSeq.setREvol(rList,rErrList,rSlope,rConst)
        fitResultSeq.setBEvol(bList,bErrList,bSlope,bConst)
        fitResultSeq.setAEvol(aList,aErrList,aSlope,aConst)
        
        return fitResultSeq
            
