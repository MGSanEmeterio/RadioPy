#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 25 14:04:20 2017

Title
-----
Class SNGraph

Description
-----------
This class has methods capable of graphically representing all measured and 
theoretical data. 

Metadata
-------- 
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt
"""

import os
import matplotlib.pyplot as plt
import radiopy.config as config
import radiopy.report as report
import radiopy.result as rst
import radiopy.result_sequence as rstseq
import radiopy.observation as obs
import radiopy.observation_sequence as obseq

class SNGraph:
    """
    This class has methods capable of graphically representing all data and 
    fittings
    """
    
    @staticmethod
    def plotEpoch(observ, fitResult:rst.Result):
        """
        This method plots the measured data from an Observation and the
        theoretical curve calculated with the corresponding parameters from
        the Result.
        
        Parameters
        ----------
        observ : Observation
            An instance of class Observation.
        fitting : Result
            An instance of class Result.
        """

        freq = observ.getFreq()
        flux = observ.getFlux()
        error = observ.getError()
        time = observ.getTime()
        theoCurve = fitResult.getTheoreticalCurve()
        
        title = 'Day ' + str(time)
        axeX = config.SNConfig.plotEpochAxeX
        axeY = config.SNConfig.plotEpochAxeY
        
        plt.loglog(freq,flux,'bo')
        plt.errorbar(freq, flux,yerr=error,fmt='none')
        plt.loglog(theoCurve['freqExpanded'],theoCurve['sFlux'],'r--')
        axes = plt.gca()
        axes.set_xlim(axeX)
        axes.set_ylim(axeY)
        plt.ylabel('S (mJy)')
        plt.xlabel(r'$\nu$ (GHz)')
        plt.title(title)
        plt.show()
        
        
    @staticmethod
    def plotSequence(observSeq:obseq.ObservationSequence, 
                     fitResultSeq:rstseq.ResultSequence):
        """
        This method plots the measured data from a sequence of Observation
        instances and the theoretical curves calculated with the
        corresponding parameters from a sequence of Result instances.
        
        Parameters
        ----------
        observSeq : ObservationSequence
            An instance of ObservationSequence.
        fittingSeq : ResultSequence
            An instance of ResultSequence.
        """

        num = observSeq.getNumObservations()
        for i in range(0,num):
            observ = observSeq.getObservation(i)
            fitResult = fitResultSeq.getResult(i)
            SNGraph.plotEpoch(observ,fitResult)
            report.Report.infoEpoch(fitResult)
        
            
    @staticmethod
    def plotTimeEvol(fitResultSeq:rstseq.ResultSequence):
        """
        This method plots the time evolution for physical parameters 
        R, B and A.
        
        Parameters
        ----------
        fittingSeq : ResultSequence
            An instance of ResultSequence, fittingSeq is a list of objects of
            class Result.
        """

        tList = fitResultSeq.getTimeList()
        rEvol = fitResultSeq.getREvol()
        bEvol = fitResultSeq.getBEvol()
        aEvol = fitResultSeq.getAEvol()
        print(' ')
        print('Average exponent p above all epochs - p_avg = ',
              fitResultSeq.getPAvg()[0],' +- ',fitResultSeq.getPAvg()[1])
        # Plot rEvol
        rFit = list()
        for i in range(0,len(tList)):    
            rFit.append(rEvol[3]*tList[i]**(rEvol[2]))
        plt.loglog(tList, rEvol[0], 'bo',ms=5)
        plt.errorbar(tList, rEvol[0],yerr=rEvol[1],fmt='none')
        plt.loglog(tList, rFit, 'r-')
        plt.xlabel('$t$ (days)')
        plt.ylabel('$R$ (cm)')
        axes = plt.gca()
        axes.set_xlim([10,150])
        axes.set_ylim([1e15,2e16])
        plt.show()
        print('Adjustment: R = m*t + b')
        print('R: Slope m = ',rEvol[2])
        print('R: Constant b = ',rEvol[3])
        
        # Plot bEvol
        bFit = list()
        for i in range(0,len(tList)):
            bFit.append(bEvol[3]*tList[i]**(bEvol[2]))
        plt.loglog(tList, bEvol[0], 'bo',ms=5)
        plt.errorbar(tList, bEvol[0],yerr=bEvol[1],fmt='none')
        plt.loglog(tList, bFit, 'r-')
        plt.xlabel('$t$ (days)')
        plt.ylabel('$B$ (G)')
        axes = plt.gca()
        axes.set_xlim([10,150])
        axes.set_ylim([0.1,3])
        plt.show()
        print('Adjustment: B = m*t + b')
        print('B: Slope m = ',bEvol[2])
        print('B: Constant b = ',bEvol[3])
        
        # Plot aEvol
        aFit = list()
        for i in range(0,len(tList)):
            aFit.append(aEvol[3]*tList[i]**(aEvol[2]))
        plt.loglog(tList, aEvol[0], 'bo',ms=5)
        plt.errorbar(tList, aEvol[0],yerr=aEvol[1],fmt='none')
        plt.loglog(tList, aFit, 'r-')
        plt.xlabel('$t$ (days)')
        plt.ylabel(r'$A_*$ (5·10$^{-11}$ · g·cm$^{-2})$')
        axes = plt.gca()
        axes.set_xlim([10,150])
        axes.set_ylim([0.5,50])
        plt.show()
        print('Adjustment: A = m*t + b')
        print('A: Slope m = ',aEvol[2])
        print('A: Constant b = ',aEvol[3])
        
        
    @staticmethod
    def saveEpoch(observ:obs.Observation, fitResult:rst.Result, fileName:str):
        """
        This method plots the measured data from an Observation and the
        theoretical curve calculated with the corresponding parameters from
        the Result.
        
        Parameters
        ----------
        observ : Observation
            An instance of class Observation.
        fitting : Result
            An instance of class Result.
        nameFile : str
            A string containing the name of the figure the method will save.
            Figures are exported in both .svg and .png formats.
        """

        myPath = config.SNConfig.figurePath
        freq = observ.getFreq()
        flux = observ.getFlux()
        error = observ.getError()
        time = observ.getTime()
        theoCurve = fitResult.getTheoreticalCurve()
        
        title = 'Day ' + str(time)
        axeX = config.SNConfig.plotEpochAxeX
        axeY = config.SNConfig.plotEpochAxeY
        
        if not os.path.exists(myPath):
            os.makedirs(myPath)

        # save figure as svg
        fig = plt.figure()
        plt.loglog(freq,flux,'bo')
        plt.errorbar(freq, flux,yerr=error,fmt='none')
        plt.loglog(theoCurve['freqExpanded'],theoCurve['sFlux'],'r--')
        axes = plt.gca()
        axes.set_xlim(axeX)
        axes.set_ylim(axeY)
        plt.ylabel('S (mJy)')
        plt.xlabel(r'$\nu$ (GHz)')
        plt.title(title)
        fileNameSVG = myPath + fileName + '.svg'
        fig.savefig(fileNameSVG, dpi=fig.dpi)

        #save figure as png
        fileNamePNG = myPath + fileName + '.png'
        fig.savefig(fileNamePNG, dpi=100)
        
    @staticmethod
    def saveSequence(observSeq:obseq.ObservationSequence, 
                     fitResultSeq:rstseq.ResultSequence):
        """
        This method saves the plots the measured data from a sequence
        of Observation instances and the theoretical curves calculated
        with the corresponding parameters from a sequence of Result instances.
        
        The plots are saved in both .svg and .png formats.

        Parameters
        ----------
        observSeq : ObservationSequence
            An instance of ObservationSequence.
        fittingSeq : ResultSequence
            An instance of ResultSequence.
        """

        num = observSeq.getNumObservations()
        for i in range(0,num):
            observ = observSeq.getObservation(i)
            fitResult = fitResultSeq.getResult(i)
            fileName = 'epoch'+str(i+1)
            SNGraph.saveEpoch(observ,fitResult,fileName)
            
            
    @staticmethod
    def saveTimeEvol(fitResultSeq:rstseq.ResultSequence):
        """
        This method plots the time evolution for physical parameters 
        R, B and A.

        The plots are saved in both .svg and .png formats.

        Parameters
        ----------
        fittingSeq : ResultSequence
            An instance of ResultSequence, fittingSeq is a list of objects of
            class Result.
        """

        tList = fitResultSeq.getTimeList()
        rEvol = fitResultSeq.getREvol()
        bEvol = fitResultSeq.getBEvol()
        aEvol = fitResultSeq.getAEvol()
        myPath = config.SNConfig.figurePath
        
        if not os.path.exists(myPath):
            os.makedirs(myPath)
        
        # Plot rEvol
        rFit = list()
        for i in range(0,len(tList)):    
            rFit.append(rEvol[3]*tList[i]**(rEvol[2]))
        rFig = plt.figure()
        plt.loglog(tList, rEvol[0], 'bo',ms=5)
        plt.errorbar(tList, rEvol[0],yerr=rEvol[1],fmt='none')
        plt.loglog(tList, rFit, 'r-')
        plt.xlabel('$t$ (days)')
        plt.ylabel('$R$ (cm)')
        axes = plt.gca()
        axes.set_xlim([10,150])
        axes.set_ylim([1e15,2e16])
        #save figure as svg
        rFig.savefig(myPath + 'r_time_evol.svg', dpi=rFig.dpi)
        #save figure as png
        rFig.savefig(myPath + 'r_time_evol.png', dpi=100)
        
        # Plot bEvol
        bFit = list()
        for i in range(0,len(tList)):
            bFit.append(bEvol[3]*tList[i]**(bEvol[2]))
        bFig = plt.figure()
        plt.loglog(tList, bEvol[0], 'bo',ms=5)
        plt.errorbar(tList, bEvol[0],yerr=bEvol[1],fmt='none')
        plt.loglog(tList, bFit, 'r-')
        plt.xlabel('$t$ (days)')
        plt.ylabel('$B$ (G)')
        axes = plt.gca()
        axes.set_xlim([10,150])
        axes.set_ylim([0.1,3])
        #save figure as svg
        bFig.savefig(myPath + 'b_time_evol.svg', dpi=bFig.dpi)
        #save figure as png
        rFig.savefig(myPath + 'b_time_evol.png', dpi=100)
        
        
        # Plot aEvol
        aFit = list()
        for i in range(0,len(tList)):
            aFit.append(aEvol[3]*tList[i]**(aEvol[2]))
        aFig = plt.figure()
        plt.loglog(tList, aEvol[0], 'bo',ms=5)
        plt.errorbar(tList, aEvol[0],yerr=aEvol[1],fmt='none')
        plt.loglog(tList, aFit, 'r-')
        plt.xlabel('$t$ (days)')
        plt.ylabel(r'$A_*$ (5·10$^{-11}$ · g·cm$^{-2})$')
        axes = plt.gca()
        axes.set_xlim([10,150])
        axes.set_ylim([0.5,50])
        #save figure as svg
        aFig.savefig(myPath + 'a_time_evol.svg', dpi=aFig.dpi)
        #save figure as png
        rFig.savefig(myPath + 'a_time_evol.png', dpi=100)
