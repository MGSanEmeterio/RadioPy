#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 24 10:40:59 2017

Title
-----
Class Model

Description
-----------
The Class KraussModel assembles a group of class methods that are used by the 
algorithm for treating radio synchrotron emissions with a power-law 
distribution of relativistic electrons, as treated in Pacholczyk (1970), 
Chevalier(1998) and Krauss+ (2012). Such features include, among others,
the model expression, calculus of the chi-square function and quadratic error.


Metadata
--------
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt
"""
import numpy as np
import abstract_model as abs_model

class KraussModel(abs_model.AbstractModel):
    """
    This class contains the equations and algorithms used to treat
    data from radio synchrotron emissions with a power-law
    distribution of relativistic electrons.
    
    It extends the AbstractModel implementing the fluxModel method
    with the model described in Krauss et al 2012
    """     
      

    # -------------------- METHODS --------------------
   
    @classmethod
    def fluxModel(cls, freq:float, **params)->float:
        """
        Model equation for radio-synchrotron emission of relativistic
        electrons.
           
        Flux vs frequency expression at Krauss et Al 2012 for theoretical
        monochromatic flux "S".
           
        Parameters
        ----------
        cls  : class 
            the current class
        freq : float 
            Single data of frequency (GHz)
        params : Dict[str,float]
            A dictionary of function parameters with names.
            It must contain these three named parameters
                'p', float
                    Exponent of the power-law distribution of electrons.
                'st', float
                    S_tau ; flux (mJy) at the frequency which the optical 
                    thickness 'tau' is 1.
                'vt', float
                    nu_tau ; frequency (GHz) at which the optical thickness tau 
                    is 1.
                
        Returns
        -------
        float
            Single value of (theoretical) monochromatic flux (mJy)

        """

        S = (1.582*params['st']*(freq/params['vt'])**(5/2) * 
             (1-np.e**( -(freq/params['vt'])**(-(params['p']+4)/2) ))) 
                   
        return S
