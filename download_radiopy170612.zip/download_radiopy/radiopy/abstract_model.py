#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 24 10:40:59 2017

Title
-----
Class Model

Description
-----------
The Class Model assembles a group of class methods that are used by the 
algorithm for treating radio synchrotron emissions with a power-law 
distribution of relativistic electrons, as treated in Pacholczyk (1970), 
Chevalier(1998) and Krauss+ (2012). Such features include, among others,
the model expression, calculus of the chi-square function and quadratic error.


Metadata
--------
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt
"""

import numpy as np
import radiopy.config as config
import radiopy.global_data as gdata
import radiopy.exceptions as excep

class AbstractModel:
    """
    This abstract class contains the equations and algorithms used to treat
    data from radio synchrotron emissions with a power-law
    distribution of relativistic electrons.
    
    The fluxModel() method needs to be overriden in a subclass using a
    concrete implementation
    """     
      

    # -------------------- METHODS --------------------
   
    @classmethod
    def fluxModel(cls, freq:float, **params)->float:
        """
        Abstract model equation for radio-synchrotron emission of 
        relativistic electrons.
       
        This method currently raises a NotImplementedError exception.
        It should be overriden with the Flux vs frequency expression.
       
        Parameters
        ----------
        cls  : class 
            the current class
        freq : float 
            Single data of frequency (GHz)
        **params : dict[str,float]
            A dictionary of function parameters with names.
            
        Returns
        -------
        float
            Single value of (theoretical) monochromatic flux (mJy)
            
        Raises
        ------
        NotImplementedError
            The method is not implemented in this abstract class; it needs
            to be overridden in a subclass

        """
        
        raise excep.NotImplementedError(
            'abstract fluxModel should be overridden')
   
       
       
    @classmethod
    def fluxModelArray(cls, freq:np.ndarray, **params)->np.ndarray :
        """Model equation for a sequence of points.
        
        Flux vs frequency expression at Krauss et Al 2012 for
        theoretical monochromatic flux "s". This function gets an
        array of frequencies and the model parameters as parameters 
        and returns an array of flux values in turn.
        
        Parameters
        ----------
        cls  : class 
            the current class
        freq : array[float] 
            Array of frequency data (GHz)
        **params : dict[str,float]
            A dictionary of function parameters with names.
        
        Returns
        -------
        array[float]
            Array of (theoretical) monochromatic flux values (mJy)

        """
        s = np.zeros(len(freq))
        for i in range(0,len(freq)):
            s[i]=cls.fluxModel(freq[i], **params)
        return s
        

    @classmethod
    def chiSq(cls, freq:float, flux:float, error:float, **params)->float:
        """
        Logarithmic weighted quadratic error for a single point.
        
        Calculates the weighted quadratic error at logarithmic scale
        for a single point (frequency,flux). This is a comparison between
        the actual masured point and a theoretical one obtained
        by application of classmethod 'krauss'.

                
        Parameters
        ----------
        cls  : class 
            the current class
        freq : float 
            Single data of frequency (GHz).
        flux : float
            Single measurement of flux (mJy)
        error : float
            Single data of flux error (mJy)
        **params : dict[str,float]
            A dictionary of function parameters with names.
        
        Returns
        -------
        float
            Logarithmic weighted quadratic error for a single point.
        """
        
        chiSq = (np.log(flux) - 
                 np.log(cls.fluxModel(freq,**params)))**2 / np.log(error)**2
        
        return chiSq

    
    @classmethod
    def rChiSq(cls, freq:float, flux:float, error:float, **params)->float:
        """
        Weighted quadratic error for a single point.
        
        Calculates the weighted quadratic error for a single point 
        (frequency,flux). This is a comparison between the actual
        masured point and a theoretical one obtained by application of
        classmethod 'krauss'.
        
        Parameters
        ----------
        cls  : class 
            the current class
        freq : float 
            Single data of frequency (GHz).
        flux : float
            Single measurement of flux (mJy)
        error : float
            Single data of flux error (mJy)
        **params : dict[str,float]
            A dictionary of function parameters with names.
        
        Returns
        -------
        float
            Weighted quadratic error for a single point.
        """

        rChiSq = (flux - cls.fluxModel(freq,**params))**2 / error**2
        
        return rChiSq
        
        
    @classmethod   
    def chiSqSum(cls, freq:np.ndarray, flux:np.ndarray, 
                 error:np.ndarray, **params)->float:
        """
        Logarithmic chi-square function for a sequence of points.
        
        Calculates the summation of weighted quadratic error 
        at logarithmic scale for a sequence of measurements (frequency,flux).
        
        Parameters
        ----------
        cls  : class 
            the current class
        freq : array[float]
            Array of frequency data (GHz).
        flux : array[float]
            Array of flux measurements (mJy)
        error : array[float]
            Array of flux incertainties (mJy)
        **params : dict[str,float]
            A dictionary of function parameters with names.
        
        Returns
        -------
        float
            Logarithmic chi-square function for a sequence of points.
        """

        chiSqSum = 0
        for i in range(0,len(freq)):
            chiSqSum = chiSqSum + cls.chiSq(freq[i],flux[i],error[i],**params)
            
        return chiSqSum
        
        
    @classmethod
    def rChiSqSum(cls, freq:np.ndarray, flux:np.ndarray, 
                  error:np.ndarray, **params)->float:
        """
        Chi-square function for a sequence of points.
        
        Calculates the summation of weighted quadratic error for a sequence
        of measurements (frequency,flux).
                
        Parameters
        ----------
        cls  : class 
            the current class
        freq : array[float]
            Array of frequency data (GHz).
        flux : array[float]
            Array of flux measurements (mJy)
        error : array[float]
            Array of flux incertainties (mJy)
        **params : dictionary(name,float)
            A dictionary of function parameters with names.
        
        Returns
        -------
        float
            Chi-square function for a sequence of points.
        """

        rChiSqSum = 0
        for i in range(0,len(freq)):
            rChiSqSum = rChiSqSum + cls.rChiSq(freq[i],
                                               flux[i],error[i],**params)
            
        return rChiSqSum
        
        
    @classmethod
    def quadErr(cls, freq:float, flux:float, **params)->float:
        """
        Quadratic error for a single point.
        
        Calculates the quadratic error for a single point (frequency,flux).
        
        Parameters
        ----------
        cls  : class 
            the current class
        freq : float 
            Single data of frequency (GHz).
        flux : float
            Single measurement of flux (mJy)
        **params : dict[str,float]
            A dictionary of function parameters with names.
        
        Returns
        -------
        float
            Quadratic error for a single point.
        """
        quadErr = (flux - cls.fluxModel(freq,**params))**2
    
        return quadErr

        
    @classmethod    
    def quadErrSum(cls, freq:np.ndarray, flux:np.ndarray, **params)->float:
        """
        Quadratic error of a sequence of points.
        
        Calculates the summation of quadratic error for a sequence of
        measurements (frequency,flux).
        
        Parameters
        ----------
        cls  : class 
            the current class
        freq : array[float]
            Array of frequency data (GHz).
        flux : array[float]
            Array of flux measurements (mJy)
        **params : dict[str,float]
            A dictionary of function parameters with names.
        
        Returns
        -------
        float
            Summation of quadratic error for a sequence of points.

        """
        quadErrSum = 0
        for i in range(0,len(freq)):
            quadErrSum = quadErrSum + cls.quadErr(freq[i],flux[i],**params)
            
        return quadErrSum

        
    @classmethod
    def chiSqDiff(cls, freq:np.ndarray, flux:np.ndarray, error:np.ndarray, 
                  step:float, param:str, **params)->float:
        """
        Chi-square derivative over parameter named param.
        
        This method returns the derivative of chiSq over parameter named 
        param for a sequence of points. 
        The Chi-square function is obtained in its logarithmic form.
        
        Parameters
        ----------
        cls  : class 
            the current class
        freq : array[float]
            Array of frequency data (GHz).
        flux : array[float]
            Array of flux measurements (mJy)
        error : array[float]
            Array of flux incertainties (mJy)
        step : float
            Numeric increment for derivative calculation. Tends to zero.
        param : str
            Name of the parameter over which the derivative is calculated
        **params : dict[str,float]
            A dictionary of function parameters with names.
            
        Returns
        -------
        float
            Logarithmic chi-square differenciation over parameter st.
        """
        
        x=params[param]
        params[param]=x+step
        chiPlus=cls.chiSqSum(freq,flux,error,**params)
        params[param]=x-step
        chiMinus=cls.chiSqSum(freq,flux,error,**params)
        return (chiPlus-chiMinus)/2/step    

    @staticmethod
    def SNr(sm:float, vm:float, stdErrReg:float)->float:
        """
        This method calculates the value for the shockwave radious (cm).
        
        Parameters
        ----------
        sm : float
            Maximum theoretical flux (mJy).
        vm : float
            Frequency at which the theoretical spectra attains its
            maximum (GHz).
        stdErrReg : float
            Standard error of the regression: absolute error for sm (mJy)
            
        Returns
        -------
        r : float
            Shockwave radious of the SN (cm).
        rErr : float
            Uncertainty of the radious (cm).
        """

        al = config.SNConfig.alpha
        f = config.SNConfig.fillFactor
        d = gdata.GlobalData.eventDistance
        dErr = gdata.GlobalData.eventDistanceErr
        relativeErr = stdErrReg/sm
        
        r = 3.9e14 * al**(-1/19) * (f/0.5)**(-1/19) * d**(18/19) * sm**(9/19) * (5/vm)
        partD = 3.9e14 * al**(-1/19) * (f/0.5)**(-1/19) * 18/19*d**(-1/19) * sm**(9/19) * (5/vm)
        partSm = 3.9e14 * al**(-1/19) * (f/0.5)**(-1/19) * d**(18/19) * 9/19*sm**(-10/19) * (5/vm)
        partVm = 3.9e14 * al**(-1/19) * (f/0.5)**(-1/19) * d**(18/19) * 9/19*sm**(-10/19) * (-5/vm**2)
        rErr = np.sqrt( partD**2 * (dErr)**2 + partSm**2 * (stdErrReg)**2 + partVm**2 * (vm*relativeErr)**2)  
    
        return r,rErr
        
    @staticmethod
    def SNb(sm:float, vm:float, stdErrReg:float)->float:
        """
        This method calculates the value for the intensity
        of the magnetic field (G).
        
        Parameters
        ----------
        sm : float
            Maximum theoretical flux (mJy).
        vm : float
            Frequency at which the theoretical spectra attains its 
            maximum (GHz).
        stdErrReg : float
            Standard error of the regression: absolute error for sm (mJy)
        d : float
            Distance between observer and the event (Mpc).
        dErr : float
            Error of the distance d between obserber and object (Mpc).
            
        Returns
        -------
        b : float
            Intensity of the magnetic field B (G).
        bErr : float
            Uncertainty of the intensity of the magnetic field (G).
        """

        al = config.SNConfig.alpha
        f = config.SNConfig.fillFactor
        d = gdata.GlobalData.eventDistance
        dErr = gdata.GlobalData.eventDistanceErr
        relativeErr = stdErrReg/sm
        
        b = al**(-4/19) * (f/0.5)**(-4/19) * d**(-4/19) * sm**(-2/19) * vm/5
        partD = al**(-4/19) * (f/0.5)**(-4/19) * -4/19*d**(-23/19) * sm**(-2/19) * vm/5
        partSm =al**(-4/19) * (f/0.5)**(-4/19) * d**(-4/19) * -2/19*sm**(-21/19) * vm/5
        partVm = al**(-4/19) * (f/0.5)**(-4/19) * d**(-4/19) * sm**(-2/19) * 1/5
        bErr = np.sqrt( partD**2 * (dErr)**2 + partSm**2 * (stdErrReg)**2 + partVm**2 * (vm*relativeErr)**2   )      
    
        return b,bErr
        
        
    @staticmethod
    def SNa(sm:float, vm:float, stdErrReg:float, t:float,)->float:
        """
        This method calculates the value for the circumstellar density
        parametrized as a / (5e11 g cm-1)
        
        Parameters
        ----------
        sm : float
            Maximum theoretical flux (mJy).
        vm : float
            Frequency at which the theoretical spectra attains its 
            maximum (GHz).
        stdErrReg : float
            Standard error of the regression: absolute error for sm (mJy)
        t : float
            Age of the event in days.
            
        Returns
        -------
        a : float
            Circumstellar density (5e-11 g cm-1).
        bErr : float
            Uncertainty of the circumstellar density (5e-11 g cm-1).
        """

        al = config.SNConfig.alpha
        f = config.SNConfig.fillFactor
        eB = config.SNConfig.eB
        d = gdata.GlobalData.eventDistance
        dErr = gdata.GlobalData.eventDistanceErr
        relativeErr = stdErrReg/sm
        
        a = 0.82 * al**(-8/19) * 0.1/eB * (f/0.5)**(-8/19) * d**(-8/19) * sm**(-4/19) * (vm/5)**2 * (t/10)**2
        partD = 0.82 * al**(-8/19) * 0.1/eB * (f/0.5)**(-8/19) * -8/19*d**(-27/19) * sm**(-4/19) * (vm/5)**2 * (t/10)**2
        partSm = 0.82 * al**(-8/19) * 0.1/eB * (f/0.5)**(-8/19) * d**(-8/19) * -4/19*sm**(-23/19) * (vm/5)**2 * (t/10)**2
        partVm = 0.82 * al**(-8/19) * 0.1/eB * (f/0.5)**(-8/19) * d**(-8/19) * sm**(-4/19) * 2/25*vm * (t/10)**2
        aErr = np.sqrt( partD**2 * (dErr)**2 + partSm**2 * (stdErrReg)**2 + partVm**2 * (vm*relativeErr)**2   )
    
        return a,aErr
        
    @staticmethod    
    def modelStraightLine(x:np.ndarray, m:float, b:float)->np.ndarray:
        """
        Theoretical model for a straight-line.
        
        Parameters
        ----------
        x : array[float]
            Independent variable - a sequence of data.
        m : float
            Slope of the straight line
        b : float
            A constant. Defines the initial value for x=0. 

        Returns
        -------
        array[float]
            A sequence of values for the straight line

        """

        return m*x+b
