#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 25 12:46:13 2017

Title
-----
Class ObservationSequence

Description
-----------
This class contains as attribute a list of objects of the class Observation.
Its purpose is to study the whole set of measurements over time, i.e., its time
evolution.

Metadata
-------- 
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt
"""
import csv
import radiopy.observation as obs
import radiopy.config as config
import radiopy.global_data as gdata

class ObservationSequence:
    """
    This class contains as attribute a list of objects of the class
    Observation.  Its purpose is to study the whole set of
    measurements over time, i.e., its time evolution.
    """
 
    # -------------------- METHODS --------------------
        
    def __init__(self):
        """
        Constructor method for class ObservationSequence.

        It creates an empty list of observations
        """

        # List of class Observation instances
        self.observationList = list()

        
    def addObservation(self, observ:obs.Observation):
        """
        This method adds an instance of class Observation to the list. 
        """

        self.observationList.append(observ)
    
        
    def readCSV(self, name_CSV:str):
        """
        Reads data from a .csv file and records it in a sequence of Observation
        instances.
        
        Parameters
        ----------
        name_CSV : str
            A string containing the name of the file the method has to read.
            The name should be written between quotation marks and the
            extension should be specified. Example: 'myfile.csv'
        """

        header = config.SNConfig.numRowsHeader
        
        f = open(name_CSV, 'r')
        reader = csv.reader(f)
        
        #METADATA ROWS
        gdata.GlobalData.title = next(reader)[1]
        authors = next(reader)
        authorStr = ''
        for i in range(1,len(authors)-1):
            authorStr += authors[i]+', '
        authorStr += authors[len(authors)-1]
        gdata.GlobalData.authors = authorStr
        gdata.GlobalData.organization = next(reader)[1]
        gdata.GlobalData.eventName = next(reader)[1]
        gdata.GlobalData.eventStartDate = next(reader)[1]
        distanceStr = next(reader)[1]
        gdata.GlobalData.eventDistance = float(distanceStr)
        distanceErrStr = next(reader)[1]
        gdata.GlobalData.eventDistanceErr = float(distanceErrStr)
        gdata.GlobalData.measuringEquipment = next(reader)[1]
        
        rownum = 8
        t = -1
        observ = None
        for row in reader:
            # Save header row - i=0
            # Then
            if rownum >= header:
                # Check if it's the same epoch
                nextT = float(row[0])
                nextT = int(nextT)
                if nextT != t:
                    # New epoch
                    if t != -1:
                        # Add old Observation except for first iteration
                        self.addObservation(observ)
                    # Create a new Observation instance for the new epoch
                    observ = obs.Observation()
                    observ.setTime(float(row[0]))
    
                # csv row-list error treatment
                noTreatRow = row
                if noTreatRow[3] == '':
                    noTreatRow[3] == 0
                if noTreatRow[1] == '' or noTreatRow[2] == '':
                    print('Row ',rownum,' deleted - missing point')                   
                else:
                    for j in range(0,len(noTreatRow)):
                        noTreatRow[j] = float(noTreatRow[j]) 
                    # Add data to the current Observation
                    observ.addPoint(noTreatRow[1],noTreatRow[2],noTreatRow[3])
                    
                t = nextT
            rownum = rownum + 1
        # Add the last Observation instance to the sequence
        self.addObservation(observ)
        f.close()
        
    def writeCSV(self, name_CSV:str):
        """
        Write data from the sequence of Observation instances into a csv
        file.
        
        Parameters
        ----------
        name_CSV : str
            Name of the csv file where the data of the ObservationSequence will
            be written. Format: 'file_example.csv'

        """
        
        f = open(name_CSV, 'w')
        writer = csv.writer(f,quoting=csv.QUOTE_NONNUMERIC)
        
        num = self.getNumObservations()
        
        writer.writerow(('TITLE: ', gdata.GlobalData.title))
        writer.writerow(('AUTHOR/S: ', gdata.GlobalData.authors))
        writer.writerow(('ORGANIZATION: ', gdata.GlobalData.organization))
        writer.writerow(('NAME OF THE EVENT: ', gdata.GlobalData.eventName))
        writer.writerow(('START DATE OF THE EVENT: ',
                         gdata.GlobalData.eventStartDate))
        writer.writerow(('DISTANCE TO THE EVENT (Mpc): ',
                         gdata.GlobalData.eventDistance))
        writer.writerow(('UNCERTAINTY ON THE DISTANCE (Mpc): ',
                         gdata.GlobalData.eventDistanceErr))
        writer.writerow(('MEASURING EQUIPMENT: ',
                         gdata.GlobalData.measuringEquipment))

        writer.writerow(('t (days)','Freq (GHz)','Flux (mJy)',
                         'fluxErr (mJy)'))
        
        for i in range(0,num):
            observ = self.getObservation(i)
            t = observ.getTime()
            freq = observ.getFreq()
            flux = observ.getFlux()
            error = observ.getError()
            for j in range(0,len(flux)):
                writer.writerow( (t, freq[j], flux[j],error[j]) )

        f.close()
        
    def getNumObservations(self)->int:
        """
        Returns the number of observations or epochs.
        
        Returns
        -------
        int
            Number of epochs/observations.
        """

        return len(self.observationList)
                
        
    def getObservation(self, index:int)->obs.Observation:
        """
        Returns the observation of the list indicated by the index.
        
        Parameters
        ----------
        index : int
            Observation's index from the observationList.
        
        Returns
        -------
        Observation
            Returns the instance of class Observation from the observationList
            corresponding to the given index.
        """

        return self.observationList[index]
